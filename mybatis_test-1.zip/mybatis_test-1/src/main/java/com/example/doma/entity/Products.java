package com.example.doma.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class Products {
	private Integer id;
	private String name;
	private String description ;
	private BigDecimal price;
	private Integer stock;
	private LocalDateTime createdAt;
	
}
