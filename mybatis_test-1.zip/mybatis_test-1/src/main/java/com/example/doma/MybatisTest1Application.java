package com.example.doma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.example")
public class MybatisTest1Application {

	public static void main(String[] args) {
		SpringApplication.run(MybatisTest1Application.class, args);
	}

}
